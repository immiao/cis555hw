package edu.upenn.cis455.mapreduce;

import edu.upenn.cis.stormlite.spout.FileSpout;

public class MyFileSpout extends FileSpout {

	@Override
	public String getFilename() {
		// TODO Auto-generated method stub
		return null;
	}

}

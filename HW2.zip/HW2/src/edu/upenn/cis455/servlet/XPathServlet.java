package edu.upenn.cis455.servlet;

import javax.servlet.http.*;

@SuppressWarnings("serial")
public class XPathServlet extends HttpServlet {
	
	/* TODO: Implement user interface for XPath engine here */
	
	/* You may want to override one or both of the following methods */

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response)
    {
		/* TODO: Implement user interface for XPath engine here */
	}

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
	{
		/* TODO: Implement user interface for XPath engine here */
	}

}










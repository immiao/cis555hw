package edu.upenn.cis455.crawler;

public class InvalidHttpResponseException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}

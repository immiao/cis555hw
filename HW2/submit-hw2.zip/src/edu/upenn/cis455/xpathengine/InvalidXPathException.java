package edu.upenn.cis455.xpathengine;

public class InvalidXPathException extends Exception {

}
